#include "socketServer.h"
#include <iostream>
//#include "keyboard.h"
using namespace std;

socketServer::socketServer( int port )
{
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl (INADDR_ANY );
    servaddr.sin_port = htons( port );

    cout << "socket server construct function" << endl;

    if( ( listenfd = socket( AF_INET, SOCK_STREAM, 0 ) ) == -1 )
    {
        cout <<  "create socket error:" << strerror( errno ) << "errno:" << errno << endl;
        exit( -1 );
    }

    if( bind( listenfd, (struct sockaddr*)&servaddr, sizeof(servaddr) ) == -1 )
    {
        cout <<  "bind socket error:" << strerror( errno ) << "errno:" << errno << endl;
        exit( -1 );
    }

    if( listen( listenfd, 10 ) == -1 )
    {
        cout <<  "listen socket error:" << strerror( errno ) << "errno:" << errno << endl;
        exit( -1 );
    }

    cout << "socket construct success!" << endl;
}

void socketServer::waiting()
{
    connfd = 0;
    cout << "waiting for client's request" << endl;

    //create key thread, while key 1 is pressed, the program exit
    keyThread();

    if( ( connfd = accept( listenfd,  (struct sockaddr*)NULL, NULL) ) == -1 )
    {   
        // printf( "accept socket error\n" );
        cout << "accept socket error!" << endl;
        return;
    }
    else
    {
       std::cout << "Net Server :: connect success!" << std::endl;
      // printf( "connect success!\n" );
    }

    exit_con_flag = 0;
        
    setCmd();
    //if connect success, create read thread to read msg from cilent
    readThread();

        //while connection isn't finished, continue to send map data
    //    while( !exit_con_flag )
      //      writeMsg( nameGetFromArm );
   // }
}


/***********create Key thread**************/
void socketServer::keyThread()
{
    pthread_t thread;
    int rc;
    rc = pthread_create( &thread, NULL, keyExit, this );
    if( rc )
    {
        cout << "error create exit thread" << endl;
        exit( -1 );
    }
    else
    {
        cout << "create keyThread success!" << endl;
    }

    return ;
}

void socketServer::readThread()
{
    pthread_t thread;
    int rc;
    rc = pthread_create( &thread, NULL, readMsg, this );
    if( rc )
    {
        cout << "error create read thread" << endl;
        exit( -1 );
    }
    else
    {
        cout << "create readThread success!" << endl;
    }

    return ;
}

void* socketServer::keyExit( void *arg )
{
    socketServer *s = (socketServer *) arg;
    int buttons_fd;
    char buttons[6] = {'0', '0', '0', '0', '0', '0'};

    buttons_fd = open( "/dev/buttons", 0 );
    if( buttons_fd < 0 )
    {
        perror( "open device buttons" );
        exit( 1 ); 
    }

    while( 1 )
    {
        char current_buttons[6];
        if( read( buttons_fd, current_buttons, sizeof( current_buttons ) ) != sizeof( buttons ) )
        {
            perror( "read buttons" );
            exit( 1 );
        }
        
        //while key 1 is pressed
        if( buttons[0] == '1' && current_buttons[0] == '0' )
        {
            cout <<  "exit!" << endl;
            close( s->connfd );
            close( s->listenfd );
            exit( 0 );
        }
        buttons[0] = current_buttons[0];
    }
}

void* socketServer::readMsg( void *arg )
{
    socketServer *s = (socketServer *) arg;
    int n;
    while( 1 )
    {
        n = recv( s->connfd, s->recBuf, MAXLINE, 0 );

        s->recBuf[n] = '\0';

        
        //if receive 0, the connection is cut by cilent
        if( n == 0 )
        {
            cout << "disconnected!" << endl;
            close( s->connfd );

            s->exit_con_flag = 1; //stop send msg
            pthread_exit( NULL );
        }

        //解码收到的数据
        if( s->recBuf[0] == 'f' )
        {
            s->cmd = 1;
        }
        if( s->recBuf[1] == 'l' )
        {
            s->cmd = 2;
        }
        if( s->recBuf[2] == 'r' )
        {
            s->cmd = 3;
        }
        if( s->recBuf[3] == 'b' )
        {
            s->cmd = 4;
        }

    }
}

/**************transfer size which is int to char, eg. 123 -> "123"***********/
void socketServer::intToChar( long size, char * trans )
{
    if( size == 0 )
    {
        trans[0] = '0';
        return ;
    }

    int i = 0;

    while( size != 0 )
    {
        trans[i++] = size - size / 10 * 10 + 48;
        size /= 10;
    }

    trans[i] = '\0';

    for( int x = 0; x <= (i - 1) / 2; ++x )
    {
        int temp = trans[x];
        trans[x] = trans[i - 1 - x];
        trans[i - x - 1] = temp;
    }
    
}

/*****send data to cilent***************/
void socketServer::writeMsg( string file_name_str )
{
    int len = 0;

   // static long num = 132315;
    
   // char file_name[43] = "./MapSnapShoots/ocpMap20120101_";

    //char num_ch[6];
    //intToChar( num , num_ch );

    //file_name[30] = '_';
   /* for( int i = 0; i < 6; ++i )
    {
        file_name[31 + i] = num_ch[i];
    }

    char back[5] = ".jpg";
    for( int i = 0; i < 5; ++i )
    {
        file_name[37 + i] = back[i];
    }

    file_name[42] = '\0';

    num++;

    if( num == 132520 )
        num = 132315;*/

    cout <<  file_name_str << endl;;

    char file_name[60];
    strcpy( file_name, file_name_str.c_str() );
    FILE *fd = fopen( file_name, "rb" );

    if( fd == NULL )
    {
        cout <<  "file open error!" << endl;
        //exit( 1 );
        return;
    }

    struct stat buf;

    if( stat( file_name, &buf ) < 0 )
    {
        cout << "get file stat failed!" << endl;
        return ;
    }
//    printf( "%lu\n", (unsigned long)buf.st_size );           //获取图片大小 

    long file_size = buf.st_size;
    char transfer_size[10];
    char rest_size[5];
    int rest = MAXLINE >= file_size ? MAXLINE - file_size : MAXLINE - file_size % MAXLINE;

   // printf( "rest = %d\n", rest );

    //将发送溢出量转化为char型
    intToChar( rest, rest_size );
    //将图片大小转化为char型
    intToChar( file_size, transfer_size );

   // printf( "b=%s\n", transfer_size );        

    //传送帧头
    int head_flag = send( connfd, "H", 1, 0 );   
    if( head_flag < 0 )
        cout << "send msg error:" << strerror( errno ) << "errno: " << errno << endl;
        
    //传送数据大小
    int a = send( connfd, transfer_size, sizeof( transfer_size ), 0 );  
    if( a  < 0 )
        cout << "send msg error:" << strerror( errno ) << "errno: " << errno << endl;
    
    //传送剩下的值大小
    int rest_flag = send( connfd, rest_size, sizeof( rest_size ), 0 );
    if( rest_flag < 0 )
        cout << "send msg error:" << strerror( errno ) << "errno: " << errno << endl;
 
    while( !feof(fd) )
    {
        len = fread( sendBuf, 1, MAXLINE, fd );
        printf( "%d\n", len );
        if( len <= 0 )
        {
            cout << "send msg complete:" << strerror( errno ) << "errno: " << errno << endl;
            break;
        }
        else if( ( send( connfd, sendBuf, sizeof( sendBuf ) , 0 ) ) < 0)  
        {  
            cout << "send msg error:" << strerror( errno ) << "errno: " << errno << endl;
            exit(0);  
        }
        else
            ;
          //  printf( "write success!\n");
    }

    fclose( fd );

    //wait for xms
    usleep( 400000 );
}
    
/**************get cmd************/
int socketServer::getCmd()
{
    return cmd;
}

/************set filename********/
void socketServer::setFileName( string name )
{
   // file_name_str = name;
    return;
}

/***********get ExitFlag**********/
int socketServer::getExitFlag()
{
    return exit_con_flag;
}

/*********set Cmd 0************/
void socketServer::setCmd()
{
    cmd = 0;
}
