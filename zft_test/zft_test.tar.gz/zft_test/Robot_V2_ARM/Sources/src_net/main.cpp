#include "socketServer.h"

int main( int argc, char *argv[] )
{
    socketServer Server;
    
    Server.waiting();

    return 0;
}
