#include "mapping.h"

int main(int argc, char const *argv[])
{
	if( argc != 2 )
	{
		cout << "Usage: test_map_PP <map image file name>" << endl;
		return -1;
	}

	const string fileName = argv[1];
	const string winNameSrc = "Source image";
	const string winNameOpenCv = "OpenCv Process";
	const string winNameMy = "Self define Process";

	const string winNameBlur = "Blur";
	const string winNameMedianBlur = "Median Blur";
	const string winNameGaussianBlur = "Gaussian Blur";
	const string winNameBilateralFileter = " Bilateral Filter ";

	Mat Mat_srcMapImg = imread( fileName, 0 );
	if( !Mat_srcMapImg.data )
	{
		cout << "Failed to Load the source image, the file path is: " << fileName << endl;
		return -1;
	}
	namedWindow( winNameSrc, CV_WINDOW_AUTOSIZE );
	namedWindow( winNameBlur, CV_WINDOW_AUTOSIZE );
	cvMoveWindow( winNameBlur.c_str(), Mat_srcMapImg.rows,0 );
	namedWindow( winNameMedianBlur, CV_WINDOW_AUTOSIZE );
	cvMoveWindow( winNameMedianBlur.c_str(), 0, Mat_srcMapImg.cols );
	namedWindow( winNameGaussianBlur, CV_WINDOW_AUTOSIZE );
	cvMoveWindow( winNameGaussianBlur.c_str(), Mat_srcMapImg.rows, Mat_srcMapImg.cols );
	namedWindow( winNameBilateralFileter, CV_WINDOW_AUTOSIZE );
	cvMoveWindow( winNameBilateralFileter.c_str(), Mat_srcMapImg.rows, Mat_srcMapImg.cols );

	
	Mat Mat_blurImage, Mat_medianBlurImage, Mat_GaussianBlurImage, Mat_BilaFilter;
	int blur_size = 3;
	double t0,t1,t2,t3;
	t0 = (double)cv::getTickCount();

	blur( Mat_srcMapImg, Mat_blurImage, Size(blur_size, blur_size) );
	t1 = (double)cv::getTickCount();

	medianBlur( Mat_srcMapImg, Mat_medianBlurImage, blur_size );
	t2 = (double)cv::getTickCount();

	GaussianBlur( Mat_srcMapImg, Mat_GaussianBlurImage, Size(blur_size, blur_size), 0, 0 );
	t3 = (double)cv::getTickCount();

	bilateralFilter( Mat_srcMapImg, Mat_BilaFilter, blur_size, 1, 0.1);
	cout << "Time usage: "
		 << "\n\t blur      : " << ( t1 - t0 )/cv::getTickFrequency()
		 << "\n\t medianBlur: " << ( t2 - t1 )/cv::getTickFrequency()
		 << "\n\t Gaussian  : " << ( t3 - t2 )/cv::getTickFrequency()
		 << endl;
	imshow( winNameSrc, Mat_srcMapImg );
	imshow( winNameBlur, Mat_blurImage );
	imshow( winNameMedianBlur, Mat_medianBlurImage );
	imshow( winNameGaussianBlur, Mat_medianBlurImage );
	imshow( winNameBilateralFileter, Mat_BilaFilter );
	waitKey(0);
	cv::destroyAllWindows();

	// Gaussian blur and median blur are better than blur and bilateralFilter
	// we choose median blur image to dilate and erode
	namedWindow( winNameSrc, CV_WINDOW_AUTOSIZE );
	namedWindow( winNameOpenCv, CV_WINDOW_AUTOSIZE );
	cvMoveWindow( winNameOpenCv.c_str(), Mat_srcMapImg.rows, 0 );
	namedWindow( winNameMy, CV_WINDOW_AUTOSIZE );
	cvMoveWindow( winNameMy.c_str(), Mat_srcMapImg.rows, Mat_srcMapImg.cols );

	int type2 = MORPH_ELLIPSE; // MORPH_RECT / MORPH_CROSS / MORPH_ELLIPSE
	int size2 = 4;
	Mat element2 = getStructuringElement( type2, Size( 2*size2 + 1, 2*size2+1 ), Point( size2, size2 ) );
	Mat Mat_erodeImage, Mat_dilateImage, Mat_dstOpenCv;

	erode(  Mat_medianBlurImage, Mat_erodeImage, element2 );
	dilate( Mat_erodeImage, Mat_dilateImage, element2 );

	imshow( winNameSrc, Mat_medianBlurImage );
	imshow( winNameOpenCv, Mat_erodeImage );
	imshow( winNameMy, Mat_dilateImage );
	waitKey( 0 ); // wait 1.5s
	cv::destroyAllWindows();

	//

	return 0;	
}