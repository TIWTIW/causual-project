
#ifndef _TEST_UNIT_H_
#define _TEST_UNIT_H_
#include "COMUART.h"



void COM_UART_test( void );

void CMD_Test( void );

#endif // _TEST_UNIT_H_