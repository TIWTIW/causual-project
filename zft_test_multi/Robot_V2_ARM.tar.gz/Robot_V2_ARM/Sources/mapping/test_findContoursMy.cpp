#include <string>
#include <iostream>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;


void icvprCcByTwoPass( const cv::Mat& srcImg, cv::Mat &MatUnkown, cv::Mat &MatFree, cv::Mat &MatOcp)
{
	if( srcImg.empty() )
	{
		cout << "icvprCcByTwoPass:: source image mat is empty!" << endl;
		return ;
	}
	if( srcImg.type() != CV_8UC1 )
	{
		cout << "ThreeThreshold:: source image is not gray image!" << endl;
		return ;
	}

	cout << "icvprCcByTwoPass:: entry" << endl;

	unsigned char CellUnknown = 127;
	cv::Mat srcImgClone = srcImg.clone();
	std::vector<int> labelSet_Unknown;
	std::vector<int> labelSet_Free;
	std::vector<int> labelSet_Ocp;
	int label_UnKnown = 0;
	int label_Free = 0;
	int label_Ocp  = 0;

	unsigned int rows = srcImg.rows;
	unsigned int cols = srcImg.cols;

	MatUnkown = cv::Mat( rows, cols, CV_8UC1, Scalar::all(255) );
	MatFree   = cv::Mat( rows, cols, CV_8UC1, Scalar::all(255) );
	MatOcp    = cv::Mat( rows, cols, CV_8UC1, Scalar::all(255) );

	cv::imwrite( "testInit.jpg", MatUnkown );
	// 1. first pass
	for( unsigned int i = 0; i < rows; i++ )
	{
		for( unsigned int j = 0; j < cols; j++ )
		{
			unsigned char piexVal = srcImg.at<uchar>(i, j);
			//cout << cv::Point(i,j) << "=" << (int)piexVal << endl;
			
			if( piexVal == CellUnknown )
			{
				// unknown grid
				std::vector<int> neighborLabels;
				if( i == 0 && j == 0 )
				{
					// no neighbors
				}
				else if( i == 0 && j != 0 )
				{
					// only left
					unsigned char leftPiex = srcImg.at<uchar>(i, j-1);
					if( leftPiex == CellUnknown )
					{
						int label = MatUnkown.at<uchar>(i,j-1);
						neighborLabels.push_back( label );
					}
				}
				else if( i != 0 && j == 0 )
				{
					// only up 
					unsigned char uppiex = srcImg.at<uchar>(i-1, j);
					if( uppiex == CellUnknown )
					{
						int label = MatUnkown.at<uchar>(i-1,j);
						neighborLabels.push_back( label );
					}
				}
				else
				{
					unsigned char leftPiex = srcImg.at<uchar>(i, j-1);
					unsigned char uppiex   = srcImg.at<uchar>(i-1, j);
					unsigned char upleftpiex = srcImg.at<uchar>(i-1, j-1);
					if( leftPiex == CellUnknown )
					{
						int label = MatUnkown.at<uchar>(i, j-1);
						neighborLabels.push_back( label );
					}
					if( uppiex == CellUnknown )
					{
						int label = MatUnkown.at<uchar>(i-1, j);
						neighborLabels.push_back( label );
					}
					if( upleftpiex == CellUnknown )
					{
						int label = MatUnkown.at<uchar>(i-1, j-1);
						neighborLabels.push_back( label );
					}
				}

				if( neighborLabels.empty() )
				{
					// new label grid
					//cout << "New Label at" << cv::Point(i,j) << "=" << label_UnKnown << endl;
					labelSet_Unknown.push_back( label_UnKnown );
					MatUnkown.at<uchar>(i,j) = label_UnKnown;
					labelSet_Unknown[label_UnKnown] = label_UnKnown;
					label_UnKnown ++;
				}
				else
				{
					std::sort( neighborLabels.begin(), neighborLabels.end() );
					int smallestLabel = neighborLabels.at(0);
					MatUnkown.at<uchar>(i,j) = smallestLabel;

					// save equivalence
					for( size_t k = 0; k < neighborLabels.size(); k++ )
					{
						int tmpLabel = neighborLabels.at(k);
						int & oldSmallestLabel = labelSet_Unknown.at(tmpLabel);
						if( oldSmallestLabel > smallestLabel )
						{
							labelSet_Unknown[oldSmallestLabel] = smallestLabel;
							oldSmallestLabel = smallestLabel;
						}
						else if( oldSmallestLabel < smallestLabel )
						{
							labelSet_Unknown[smallestLabel] = oldSmallestLabel;
						}
					}
				}
			}
			else if( piexVal > CellUnknown )
			{
				// free grid
				std::vector<int> neighborLabels;
				if( i == 0 && j == 0 )
				{
					// no neighbors
				}
				else if( i == 0 && j != 0 )
				{
					// only left
					unsigned char leftPiex = srcImg.at<uchar>(i, j-1);
					if( leftPiex > CellUnknown )
					{
						int label = MatFree.at<uchar>(i,j-1);
						neighborLabels.push_back( label );
					}
				}
				else if( i != 0 && j == 0 )
				{
					// only up 
					unsigned char uppiex = srcImg.at<uchar>(i-1, j);
					if( uppiex > CellUnknown )
					{
						int label = MatFree.at<uchar>(i-1,j);
						neighborLabels.push_back( label );
					}
				}
				else
				{
					unsigned char leftPiex = srcImg.at<uchar>(i, j-1);
					unsigned char uppiex   = srcImg.at<uchar>(i-1, j);
					unsigned char upleftpiex = srcImg.at<uchar>(i-1, j-1);
					if( leftPiex > CellUnknown )
					{
						int label = MatFree.at<uchar>(i, j-1);
						neighborLabels.push_back( label );
					}
					if( uppiex > CellUnknown )
					{
						int label = MatFree.at<uchar>(i-1, j);
						neighborLabels.push_back( label );
					}
					if( upleftpiex > CellUnknown )
					{
						int label = MatFree.at<uchar>(i-1, j-1);
						neighborLabels.push_back( label );
					}
				}

				if( neighborLabels.empty() )
				{
					// new label grid
					//cout << "New Label at" << cv::Point(i,j) << "=" << label_UnKnown << endl;
					labelSet_Free.push_back( label_Free );
					MatFree.at<uchar>(i,j) = label_Free;
					labelSet_Free[label_Free] = label_Free;
					label_Free ++;
				}
				else
				{
					std::sort( neighborLabels.begin(), neighborLabels.end() );
					int smallestLabel = neighborLabels.at(0);
					MatFree.at<uchar>(i,j) = smallestLabel;

					// save equivalence
					for( size_t k = 0; k < neighborLabels.size(); k++ )
					{
						int tmpLabel = neighborLabels.at(k);
						int & oldSmallestLabel = labelSet_Free.at(tmpLabel);
						if( oldSmallestLabel > smallestLabel )
						{
							labelSet_Free[oldSmallestLabel] = smallestLabel;
							oldSmallestLabel = smallestLabel;
						}
						else if( oldSmallestLabel < smallestLabel )
						{
							labelSet_Free[smallestLabel] = oldSmallestLabel;
						}
					}
				}
			}
			else
			{
				// occupied grid
				std::vector<int> neighborLabels;
				if( i == 0 && j == 0 )
				{
					// no neighbors
				}
				else if( i == 0 && j != 0 )
				{
					// only left
					unsigned char leftPiex = srcImg.at<uchar>(i, j-1);
					if( leftPiex < CellUnknown )
					{
						int label = MatOcp.at<uchar>(i,j-1);
						neighborLabels.push_back( label );
					}
				}
				else if( i != 0 && j == 0 )
				{
					// only up 
					unsigned char uppiex = srcImg.at<uchar>(i-1, j);
					if( uppiex < CellUnknown )
					{
						int label = MatOcp.at<uchar>(i-1,j);
						neighborLabels.push_back( label );
					}
				}
				else
				{
					unsigned char leftPiex = srcImg.at<uchar>(i, j-1);
					unsigned char uppiex   = srcImg.at<uchar>(i-1, j);
					unsigned char upleftpiex = srcImg.at<uchar>(i-1, j-1);
					if( leftPiex < CellUnknown )
					{
						//cout << Point(i, j-1) << "=leftPiex" << (int)leftPiex << endl;
						int label = MatOcp.at<uchar>(i, j-1);
						neighborLabels.push_back( label );
					}
					if( uppiex < CellUnknown )
					{
						//cout << Point(i-1, j) << "=uppiex" << (int)uppiex << endl;
						int label = MatOcp.at<uchar>(i-1, j);
						neighborLabels.push_back( label );
					}
					if( upleftpiex < CellUnknown )
					{
						//cout << Point(i-1, j-1) << "=upleftpiex" << (int)upleftpiex << endl;
						int label = MatOcp.at<uchar>(i-1, j-1);
						neighborLabels.push_back( label );
					}
				}
				//cout << "neighborLabels ocp: " << neighborLabels.size() << endl;

				if( neighborLabels.empty() )
				{
					// new label grid
					//cout << "New Label at" << cv::Point(i,j) << "=" << label_UnKnown << endl;
					labelSet_Ocp.push_back( label_Ocp );
					MatOcp.at<uchar>(i,j) = label_Ocp;
					labelSet_Ocp[label_Ocp] = label_Ocp;
					label_Ocp ++;
				}
				else
				{
					std::sort( neighborLabels.begin(), neighborLabels.end() );
					int smallestLabel = neighborLabels.at(0);
					//cout << "smallestLabel: " << smallestLabel << endl;
					MatOcp.at<uchar>(i,j) = smallestLabel;

					// save equivalence
					for( size_t k = 0; k < neighborLabels.size(); k++ )
					{
						//cout << k << endl;
						
						int tmpLabel = neighborLabels.at(k);
						//cout << "tmpLabel:" << tmpLabel << endl;
						int & oldSmallestLabel = labelSet_Ocp.at(tmpLabel);
						//cout << "oldSmallestLabel:" << oldSmallestLabel << endl;
						if( oldSmallestLabel > smallestLabel )
						{
							labelSet_Ocp[oldSmallestLabel] = smallestLabel;
							oldSmallestLabel = smallestLabel;
						}
						else if( oldSmallestLabel < smallestLabel )
						{
							labelSet_Ocp[smallestLabel] = oldSmallestLabel;
						}
					}
				}
			}
		}
	}

    // update equivalent labels  
    // assigned with the smallest label in each equivalent label set  
    for (size_t i = 0; i < labelSet_Unknown.size(); i++)  
    {  
        int curLabel = labelSet_Unknown[i];  
        int preLabel = labelSet_Unknown[curLabel] ;  
        while (preLabel != curLabel)  
        {  
            curLabel = preLabel ;  
            preLabel = labelSet_Unknown[preLabel] ;  
        }  
        labelSet_Unknown[i] = curLabel ;  
    }
    for (size_t i = 0; i < labelSet_Free.size(); i++)  
    {  
        int curLabel = labelSet_Free[i];  
        int preLabel = labelSet_Free[curLabel] ;  
        while (preLabel != curLabel)  
        {  
            curLabel = preLabel ;  
            preLabel = labelSet_Free[preLabel] ;  
        }  
        labelSet_Free[i] = curLabel ;  
    }
    for (size_t i = 0; i < labelSet_Ocp.size(); i++)  
    {  
        int curLabel = labelSet_Ocp[i];  
        int preLabel = labelSet_Ocp[curLabel] ;  
        while (preLabel != curLabel)  
        {  
            curLabel = preLabel ;  
            preLabel = labelSet_Ocp[preLabel] ;  
        }  
        labelSet_Ocp[i] = curLabel ;  
    }  

	// 2. second pass
    for (int i = 0; i < rows; i++)  
    {   
        for (int j = 0; j < cols; j++)  
        {
        	unsigned char piexVal = srcImg.at<uchar>(i,j);
        	if( piexVal == CellUnknown )
        	{
	            int pixelLabel = MatUnkown.at<uchar>(i,j) ;  
	            MatUnkown.at<uchar>(i,j) = labelSet_Unknown[pixelLabel] ;
        	}
        	else if( piexVal > CellUnknown )
        	{
	            int pixelLabel = MatFree.at<uchar>(i,j) ;  
	            MatFree.at<uchar>(i,j) = labelSet_Free[pixelLabel] ;
        	}
        	else
        	{
	            int pixelLabel = MatOcp.at<uchar>(i,j) ;  
	            MatOcp.at<uchar>(i,j) = labelSet_Ocp[pixelLabel] ;
        	}
        }  
    }

    // blur the salt noise
    cv::medianBlur( MatUnkown, MatUnkown, 3 );
    cv::medianBlur( MatOcp, MatOcp, 3 );
    cv::medianBlur( MatFree, MatFree, 3 );
	//imwrite( "test.jpg", MatUnkown );
}

cv::Scalar icvprGetRandomColor()  
{  
    uchar r = 255 * (rand()/(1.0 + RAND_MAX));  
    uchar g = 255 * (rand()/(1.0 + RAND_MAX));  
    uchar b = 255 * (rand()/(1.0 + RAND_MAX));  
    return cv::Scalar(b,g,r) ;  
}

void icvprLabelColor(const cv::Mat& srcImg, cv::Mat& _colorLabelImg)   
{  
    if ( srcImg.empty() ||  
         srcImg.type() != CV_8UC1)  
    {  
        return ;  
    }  
  
    std::map<int, cv::Scalar> colors ;  
  
    unsigned int rows = srcImg.rows ;  
    unsigned int cols = srcImg.cols ;  
  
    _colorLabelImg.release() ;  
    _colorLabelImg.create(rows, cols, CV_8UC3) ;  
    _colorLabelImg = cv::Scalar::all(0);


    for( unsigned int i = 0; i < rows; i++ )
    {
    	for( unsigned int j = 0; j < rows; j++ )
    	{
    		int pixelValue = srcImg.at<uchar>(i,j);
    		if( pixelValue != 255 )
    		{
    			if( colors.count(pixelValue) <= 0 )
    			{
    				colors[pixelValue] = icvprGetRandomColor();
    			}
    			cv::Scalar color = colors[pixelValue];
    			_colorLabelImg.at<Vec3b>(i,j)[0] = color[0];
    			_colorLabelImg.at<Vec3b>(i,j)[1] = color[1];
    			_colorLabelImg.at<Vec3b>(i,j)[2] = color[2];
    		}
    	}
    }

    cout << "block number:" << colors.size() << endl;
} 

void ThreeThreshold( cv::Mat& srcImg )
{
	if( srcImg.empty() )
	{
		cout << "ThreeThreshold:: source image mat is empty!" << endl;
		return ;
	}
	if( srcImg.type() != CV_8UC1 )
	{
		cout << "ThreeThreshold:: source image is not gray image!" << endl;
		return ;
	}

	unsigned char CellUnknown = 127;

	for( unsigned int i = 0; i < srcImg.rows; i++ )
	{
		for( unsigned int j = 0; j < srcImg.cols; j++)
		{
			if( srcImg.at<uchar>(i,j) < CellUnknown-50 )
			{
				srcImg.at<uchar>(i,j) = CellUnknown-100;
			}
			else if( srcImg.at<uchar>(i,j) > CellUnknown+50 )
			{
				srcImg.at<uchar>(i,j) = CellUnknown+100;
			}
			else
			{
				srcImg.at<uchar>(i,j) = CellUnknown;
			}
		}
	}
}

int main(int argc, char const *argv[])
{
	if( argc != 2 )
	{
		cout << "Usage: test_findContoursMy <image name>" << endl;
		return -1;
	}

	// Load the source image and blur -> erode -> dilate
	const string fileName = argv[1];

	cv::Mat MatSrc = cv::imread( fileName, 0 );
	if( !MatSrc.data )
	{
		cout << "Failed to load the image, the image path is:" << fileName << endl;
		return -2;
	}
	cv::Mat MatThreshold, MatBlurImg, MatErode, MatDilated;

	// threshold the source image
	MatThreshold = MatSrc.clone();
	ThreeThreshold( MatThreshold );
	// blur the image to reduce the salt noise
	int blur_size = 3;
	cv::medianBlur( MatThreshold, MatBlurImg, blur_size );
	// erode and dilate the image
	int type2 = MORPH_ELLIPSE; // MORPH_RECT / MORPH_CROSS / MORPH_ELLIPSE
	int size2 = 4;
	cv::Mat element2 = cv::getStructuringElement( type2, cv::Size( 2*size2 + 1, 2*size2+1 ), cv::Point( size2, size2 ) );
	cv::erode(  MatBlurImg, MatErode, element2 );
	cv::dilate( MatErode, MatDilated, element2 );

	cv::imwrite( "ImgThredhold.jpg", MatThreshold );
	cv::imwrite( "ImgMedianBlur.jpg", MatBlurImg );
	cv::imwrite( "ImgErode.jpg", MatErode );
	cv::imwrite( "ImgDilate.jpg", MatDilated );

	// Get the labeled image
	cv::Mat MatLabeledUnknown, MatLabeledFree, MatLabeledOcp;
	icvprCcByTwoPass( MatDilated, MatLabeledUnknown, MatLabeledFree, MatLabeledOcp );
	cv::imshow("labeled unknown Image", MatLabeledUnknown);
	cv::imshow("labeled free Image", MatLabeledFree);
	cv::imshow("labeled ocp Image", MatLabeledOcp);
	cv::Mat colorLabelImgUnknown, colorLabelImgFree, colorLabelImgOcp;  
    icvprLabelColor(MatLabeledUnknown, colorLabelImgUnknown) ;
    icvprLabelColor(MatLabeledFree, colorLabelImgFree) ;
    icvprLabelColor(MatLabeledOcp, colorLabelImgOcp) ;  
    cv::imshow("colorImg", colorLabelImgUnknown) ;
    cv::imshow("colorImg2", colorLabelImgFree) ;
    cv::imshow("colorImg3", colorLabelImgOcp) ;  
    cv::waitKey(0);
	return 0;
}