#include "Robot_VisionNavV2.h"

static pid_t L0_pid;
static pid_t L1_pid;
static pid_t L2_pid;

int Level3_GlobalPlanning( pid_t pidnum0, pid_t pidnum1 )
{
	cout << "L3 prepare to work!" << endl;
    sleep(3);
    cout << "L3 start to work!" << endl;
    cout << "Socket Server Initialized!" << endl;
    while( true )
    {
        cout << "Fatal Error: Socket Server Exit Error!" << endl;
        sleep(2);
    }
}
